'use strict';

module.exports = function(Pelicula) {

};
