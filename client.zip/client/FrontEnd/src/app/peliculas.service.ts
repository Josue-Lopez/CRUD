import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Pelicula } from './peliculas';
import { HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';


var httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

httpOptions.headers =
  httpOptions.headers.set('Authorization', 'my-new-auth-token');


var headers: {'Content-Type: application/json', 'Accept: application/json'};
@Injectable()
export class PeliculaService{
    
    //Los servicios son declarados en el constructor y son provate
    constructor(private http: HttpClient){

    }

    getPeliculas (){
        return this.http.get('http://localhost:3000/api/peliculas');
    }

    addPeliculas(peliculas: Pelicula[]): Observable<Pelicula> {
        return this.http.post<Pelicula>('http://localhost:3000/api/peliculas', peliculas)
    }

    updatePeliculas (peliculas, id){
      let body = JSON.stringify(peliculas);
      return this.http.patch('http://localhost:3000/api/peliculas/' + id, body, httpOptions);
  }

    deletePeliculas (id){
      return this.http.delete('http://localhost:3000/api/peliculas/' + id);
    }
}