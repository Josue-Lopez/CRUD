import { Component, OnInit } from '@angular/core';
import { Pelicula } from './peliculas'
import { PeliculaService } from './peliculas.service';
import { error } from '@angular/compiler/src/util';

@Component({
    selector: 'seccion-peliculas',
    templateUrl: './peliculas.component.html'
})

export class PeliculasComponent implements OnInit {
    peli: Pelicula;
    peliID: String;
    peliculas: Pelicula[] = [];
    peliculasEdit: Pelicula[] = [];



    constructor(private PS: PeliculaService) {
        console.log('constructor');
        this.peli = new Pelicula('', '', '', 0, '', 0, '');
    }



    ngOnInit() {
        console.log('ngOnInit');

        this.PS.getPeliculas().subscribe(
            (datos: Pelicula[]) => {
                this.peliculas = datos;
            }
        );
    }

    get() {
        this.PS.getPeliculas().subscribe(
            (datos: Pelicula[]) => {
                this.peliculas = datos;
            }
        );
    }

    add(titulo: string, director: string, actor: string, anio: number, pais: string, rating: number, url: string): void {
        titulo = titulo.trim();
        director = director.trim();
        actor = actor.trim();
        anio = anio;
        pais = pais.trim();
        rating = rating;
        url = url.trim();

        if (!titulo || !director || !actor || !anio || !pais || !rating || !url) { return; }
        if (rating > 5) { rating = 5 } else { if (rating < 1) { rating = 1 } }
        this.peliculas.push(new Pelicula(titulo, director, actor, anio, pais, rating, url));
        this.PS.addPeliculas(this.peliculas).subscribe(
            peli => this.peliculas.push(peli)
        );
    }

    // guardar(title: string, direc: string, act: string, year: number, country: string, rat: number, ur: string): void {
    //   this.peliculasEdit.push(new Pelicula('Hombres de negro', direc, act, year, country, rat, ur));
    // window.alert("Pelicula es: "+ "Hombres de negro" + " - " + direc + " - " + act + " - " + year + " - " + country + " - " + rat + " - " + ur);
    //this.PS.updatePeliculas(this.peliculasEdit).subscribe(
    //  (res) => {
    //    window.alert('Modificado exitosamente');
    //},
    //(error) => {
    //window.alert('Error');
    //}
    //);
    //}

    databinding(item) {
        this.peli = new Pelicula(item.titulo, item.director, item.actor, item.anio, item.pais, item.rating, item.url);
        this.peliID = item.id;
    }

    update() {
        this.PS.updatePeliculas(this.peli, this.peliID).subscribe(
            (res) => {
                this.get();
            },
            (error) => {
                window.alert('Error al modificar');
            }
        );
    }

    delete(item) {
        var mensaje = confirm("¿Esta seguro de eliminar '" + item.titulo + "'?");

        if (mensaje){
            this.PS.deletePeliculas(this.peliID).subscribe(
                (res) => {
                    this.get();
                },
                (error) => {
                    window.alert('Error al eliminar');
                }
            );
        }
        else{
            return;
        }

    }

    // Update(id: string, title: string, direc: string, act: string, year: number, country: string, rat: number, ur: string): void {
    //window.alert("Pelicula es: " + id + " - " + "Hombres de negro" + " - " + direc + " - " + act + " - " + year + " - " + country + " - " + rat + " - " + ur);
    //this.peliculas.push(new Pelicula("Hombres de negro", direc, act, year, country, rat, ur));
    //}
}
