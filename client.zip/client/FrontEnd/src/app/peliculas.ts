export class Pelicula{
    titulo: string;
    director: string;
    actor: string;
    anio: number;
    pais: string;
    rating: number;
    url: string;

    constructor(
        titulo: string,
        director: string,
        actor: string,
        anio: number,
        pais: string,
        rating: number,
        url: string
    ){
        this.titulo = titulo;
        this.director = director;
        this.actor = actor;
        this.anio = anio;
        this.pais = pais;
        this.rating = rating;
        this.url = url;
    }
}